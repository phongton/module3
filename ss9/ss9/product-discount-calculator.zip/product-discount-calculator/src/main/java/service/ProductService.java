package service;

public interface ProductService {
    double percent(double price, double percent);

    double newPrice(double amount, double price);
}
